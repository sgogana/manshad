package Salary;

public class Manager		//class
{

	public double comm=500;		//variables
	public double sal=5000;		//variables

public double calManagerSalary()	//method definition to calculate manager salary
	{
		double total;
		total=sal+comm;
		return total;
	
	}		
	
}
